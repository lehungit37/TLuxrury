import React from 'react';

function RevenueManagement() {
  return <div>RevenueManagement</div>;
}

export default RevenueManagement;
