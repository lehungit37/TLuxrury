import theme from 'src/theme';
import { makeStyles } from '@mui/styles';

export const useStyles = makeStyles(() => ({
  form: {
    padding: theme.spacing(1),
  },
}));
