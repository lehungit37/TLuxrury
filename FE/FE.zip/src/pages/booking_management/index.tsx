import React from 'react';

function BookingManagement() {
  return <div>BookingManagement</div>;
}

export default BookingManagement;
