import React from 'react';

const Actions = () => {
  return <div>Actions</div>;
};

export default Actions;
