export interface IConfig {
  isDev: boolean;
  baseURL: string;
  prefix: string;
  systemName: string;
}
