export const CFormIds = {
  updateMonitoringType: 'updateMonitoringType',
  updateMonitoringGroup: 'updateMonitoringGroup',
};
