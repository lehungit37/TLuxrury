export const monitoringTypeSymbol = {
  QTN: 'QTN',
  QTKK: 'QTKK',
  TNN: 'TNN',
};
