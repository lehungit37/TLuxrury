import { IPayloadGetUser } from 'src/types/user';

export const initPayloadUser: IPayloadGetUser = {
  page: 1,
  limit: 15,
  keyword: '',
  accountSocial: false,
};
