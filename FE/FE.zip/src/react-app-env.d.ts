/// <reference types="react-scripts" />

// import { ReactNode } from 'react';

// declare module '@react-google-maps/api' {
//   export interface Marker {
//     children?: ReactNode;
//   }
// }

declare module '*.ttf';
declare module '*.otf';
declare module 'classnames';
declare module 'react-resize-layout';
declare module 'react-slick';
declare module 'devextreme-react';
declare module '*.mp3';
declare module 'd3-scale';
