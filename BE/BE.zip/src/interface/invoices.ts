export interface IStatistialFilter {
  startDate: Date;
  endDate: Date;
  roomId: string;
  timeType: "day" | "month";
}
