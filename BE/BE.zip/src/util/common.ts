import { config } from "./../config/index";

export const getContactEmail = () => {
  return "TLuxury@gmail.com";
};
